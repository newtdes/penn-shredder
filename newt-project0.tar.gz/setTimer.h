extern pid_t pid;

void setTimer(int time);