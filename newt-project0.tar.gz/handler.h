extern pid_t pid; 

void handler(int signum);